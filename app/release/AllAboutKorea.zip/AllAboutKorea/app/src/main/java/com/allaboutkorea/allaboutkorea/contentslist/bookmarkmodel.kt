package com.allaboutkorea.allaboutkorea.contentslist

data class bookmarkmodel (

    val bookmarkIsTrue : Boolean? = null


        )