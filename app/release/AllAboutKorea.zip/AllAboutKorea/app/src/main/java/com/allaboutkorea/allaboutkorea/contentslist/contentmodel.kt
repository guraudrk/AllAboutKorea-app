package com.allaboutkorea.allaboutkorea.contentslist

class contentmodel (
    val title : String ="",
    val imageUrl : String ="",
    var webUrl : String =""

        )