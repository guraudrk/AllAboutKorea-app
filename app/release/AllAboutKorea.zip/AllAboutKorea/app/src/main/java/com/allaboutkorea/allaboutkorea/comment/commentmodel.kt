package com.allaboutkorea.allaboutkorea.comment


data class commentmodel (
    val commentTitle : String = "",
    val commentCreatedTime : String =""
        )